<?php
 
try {
    $connection = new PDO('mysql:host=localhost;dbname=basehito2albertodiaz', 'root');
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>
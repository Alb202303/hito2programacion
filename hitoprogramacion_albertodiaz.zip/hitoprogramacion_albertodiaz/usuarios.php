<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Hitogrupal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="registropag.php">Registrarse</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.php">Iniciar sesión</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="perfil1.php">Perfil</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="usuarios.php">Usuarios registrados</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="logout.php">Cerrar sesión</a>     
      </li>
    </ul>
  </div>
</nav> 

<style>
        table{
            margin-left:50px ;
            margin-right: 50px;
         }
    </style>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Usuario</th>
            <th scope="col">Contraseña</th> 
            <th scope="col">Email</th>
            <th scope="col">Imagen</th>
          </tr>
        </thead>
        <tbody>

        <form method="POST" action="#">






    <?php
require_once('config.php');

  $query = $connection->prepare("call getUsuarios");
  $query->execute();

  $result = $query->fetch(PDO::FETCH_ASSOC);

  /* if (!$result) {
      echo '<p class="error">Error. Usuario o contraseña incorrectos</p>';
      header("location: login.php");
        echo "<h2>Usuarios registrados</h2>";
        require_once('config.php');
        $query = $connection->prepare("call getUsuarios");
        $query->execute(); */
        while ($row=$query->fetch()){
           echo 
            "<tr>
                <th scope='row'>".$row[0]."</th>
                <td>".$row[1]."</td>
                <td>".$row[2]."</td>
                <td>".$row[3]."</td>

                <td><img height=220px src=".$row[4]."></td>
            </tr>";
        }
      
        if(isset($_POST['eliminar'])){
          $usuarioeliminar = ($_POST['usuarioeliminar']);
          $query = $connection->prepare("DELETE FROM usuarios WHERE usuario ='$usuario'");
          $query->bindParam("usuarioeliminar", $usuarioeliminar, PDO::PARAM_STR);
          if($query){
                  header('location:usuarios.php');
          }
     }
    ?>


      </tbody>
    </table>

    <div class="mb-3">
    <h2>Eliminar Usuario</h2>
  <label for="exampleInputEmail1" class="form-label">Usuario</label>
  <input type="text" name="usuarioeliminar" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
</div>
<button type="submit" name="eliminar" class="btn btn-primary">Eliminar</button>
</form>


</body>
</html>

      
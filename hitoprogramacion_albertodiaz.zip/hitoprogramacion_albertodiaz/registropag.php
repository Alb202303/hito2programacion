<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="registropag.php">Registrarse</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.php">Iniciar sesión</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="perfil1.php">Perfil</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="usuarios.php">Usuarios registrados</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="logout.php">Cerrar sesión</a>     
      </li>
    </ul>
  </div>
</nav> 

<form method="POST" action="#">
<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Usuario</label>
    <input type="text" name="usuario" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email</label>
    <input type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Contraseña</label>
    <input type="password" name="contrasena" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Repite la contraseña</label>
    <input type="password" name="confirmarcontrasena" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Imagen de perfil</label>
    <input type="text" name="imagen" class="form-control" id="exampleInputPassword1">
  </div>
  <!-- <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div> -->
  <button type="submit" name="registrar" class="btn btn-primary">Registrarse</button>
  <h3>Si ya tienes cuenta, puedes iniciar sesión <a href="login.php">aquí</a></h3>
</form>



    <!-- CODIGO PHP -->
    
    <?php
 
include('config.php');
session_start();
 
if (isset($_POST['registrar'])) {
 
    $usuario = $_POST['usuario'];
    $email = $_POST['email'];
    $contrasena = $_POST['contrasena'];
    $confirmarcontrasena=$_POST['confirmarcontrasena'];
    $password_hash = password_hash($contrasena, PASSWORD_BCRYPT);
    $imagen=$_POST['imagen'];
   
 
    $query = $connection->prepare("SELECT * FROM usuarios WHERE EMAIL=:email");
    $query->bindParam("email", $email, PDO::PARAM_STR);
    $query->execute();
 
    if ($query->rowCount() > 0) {
        echo '<p class="error">Este email ya está registrado</p>';
    }   

    $query = $connection->prepare("SELECT * FROM usuarios WHERE USUARIO=:usuario");
    $query->bindParam("usuario", $usuario, PDO::PARAM_STR);
    $query->execute();

    if($query->rowCount()>0){
      echo '<p class="error">Este nombre de usuario está registrado</p>';
    }

    if ($contrasena!=$confirmarcontrasena){
        echo '<p class="error"> Las contraseñas no coinciden.</p>';
    }
 
    if ($query->rowCount() == 0) {
        $query = $connection->prepare('INSERT INTO usuarios (USUARIO, CONTRASENA, EMAIL, IMAGEN) VALUES (:usuario, :password_hash, :email, :imagen)');
        $query->bindParam("usuario", $usuario, PDO::PARAM_STR);
        $query->bindParam("password_hash", $password_hash, PDO::PARAM_STR);
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $query->bindParam("imagen", $imagen, PDO::PARAM_STR);
        $result = $query->execute();
 
        if ($result) {  
          echo '<script language="javascript">';
          echo 'alert("Te has registrado correctamente. ¡Bienvenido!")';
          echo '</script>';
            header("Location: perfil1.php");
            die();
        } else {
            echo '<p class="error">Error. Revisa que has introducido todo correctamente</p>';
        }
    }
}
 
?>
</body>
</html>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link href="estilo.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="registropag.php">Registrarse</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.php">Iniciar sesión</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="perfil1.php">Perfil</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="usuarios.php">Usuarios registrados</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="logout.php">Cerrar sesión</a>     
      </li>
    </ul>
  </div>
</nav> 

<table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Usuario</th>
            <th scope="col">Contraseña</th> 
            <th scope="col">Email</th>
            <th scope="col">Imagen</th>
          </tr>
        </thead>
        <tbody>

        <?php
require_once('config.php');
session_start();
if(isset($_SESSION['usuario']))
{
 echo "<h1>Bienvenido de nuevo ".$_SESSION['usuario']."</h1>";
   
}else{
  header("Location: login.php"); 
    function_alert("Debes iniciar sesión");

   
}


  $query = $connection->prepare("SELECT * FROM USUARIOS WHERE id='{$_SESSION['id']}'");
  $query->execute();

  $result = $query->fetch(PDO::FETCH_ASSOC);


  /* foreach ($query as $fila) {
    echo "<tr><td>" . $fila['id'] . "</td><td>".$fila['usuario']."</td><td>".$fila['contrasena']."</td><td>".$fila['email']."</td><td><img src=".$fila['imagen']."></td></tr>";
} */
 while ($row=$query->fetch()){
    echo 
     "<tr>
         <th scope='row'>".$row[0]."</th>
         <td>".$row[1]."</td>
         <td>".$row[2]."</td>
         <td>".$row[3]."</td>

         <td><img height=220px src=".$row[4]."></td>
     </tr>";
 }

 
 function function_alert($mensaje) {
      
    echo "<script>alert('$mensaje');</script>";
}
  

  
 ?>

<a href="eliminar.php"><input type="button" value="Eliminar"></a>

    <!-- array(':usuario'=>$_SESSION['usuario']) -->
</body>
</html>





